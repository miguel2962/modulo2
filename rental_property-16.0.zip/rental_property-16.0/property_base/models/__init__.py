# -*- coding: utf-8 -*-
# Copyright 2018-2019 OpenSynergy Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    property_object_type,
    property_object,
    property_tenacy_status,
    property_availability_status,
)
