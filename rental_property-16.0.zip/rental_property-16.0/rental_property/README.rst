.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

===============
Rental Property
===============


Installation
============


Credits
=======

Contributors
------------

* Michael Viriyananda <viriyananda.michael@gmail.com>

Maintainer
----------

.. image:: https://opensynergy-indonesia.com/logo.png
   :alt: OpenSynergy Indonesia
   :target: https://opensynergy-indonesia.com

This module is maintained by the OpenSynergy Indonesia.
