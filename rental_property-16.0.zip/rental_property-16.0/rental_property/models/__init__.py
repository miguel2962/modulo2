# -*- coding: utf-8 -*-
# Copyright 2019 OpenSynergy Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    rental_property_detail,
    rental_property,
    rental_property_detail_schedule,
    rental_property_detail_recurring,
    rental_property_recurring_fee_schedule,
    property_object,
    rental_property_upfront_cost,
)
